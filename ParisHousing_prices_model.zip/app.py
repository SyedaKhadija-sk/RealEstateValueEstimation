import pandas as pd
from flask import Flask, render_template, request
import pickle
import numpy as np

app = Flask(__name__)
data = pd.read_csv("Cleaned_data.csv")
pipe = pickle.load(open("ParisHousing_prices_model.pickle", 'rb'))

@app.route('/hi')
def index():
    locations = sorted(data['location'].unique())
    return render_template('main.html', locations=locations)

@app.route('/predict', methods=['POST'])
def predict():
   
        location = request.form.get('location')
        area = float(request.form.get('squareMeters'))
        bhk = int(request.form.get('numberOfRooms'))

        print(location, area, bhk)
        input_data = pd.DataFrame([[location, area, bhk]], columns=['location', 'squareMeters', 'numberOfRooms'])
            # One-hot encode the 'location' feature
        input_data = pd.get_dummies(input_data, columns=['location'])

        # Ensure the order of columns matches the order during training
        input_data = input_data.reindex(columns=data.columns, fill_value=0)
        input_data = input_data.drop(['price','location'], axis=1)
            # Ensure 'location' is present in the input data
     
        prediction = pipe.predict(input_data)[0]
        formatted_prediction = '{:.2f}'.format(prediction)
        return str(formatted_prediction)
    
        # return str(prediction)

if __name__ == "__main__":
    app.run(debug=True, port=5000)
